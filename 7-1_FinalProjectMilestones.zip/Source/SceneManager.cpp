///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  Constructor
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;
}

/***********************************************************
 *  Destructor
 ***********************************************************/
SceneManager::~SceneManager()
{
	DestroyGLTextures();

	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width, height, channels;
	GLuint textureID;

	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);

	if (image)
	{
		std::cout << "Loaded: " << filename << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		else if (channels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0);

		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Failed to load: " << filename << std::endl;
	return false;
}

/***********************************************************
 *  Bind textures
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  Destroy textures
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  Find texture slot
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
			return i;
	}
	return -1;
}

/***********************************************************
 *  Find material
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

/***********************************************************
 *  Transformations
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float xRot,
	float yRot,
	float zRot,
	glm::vec3 positionXYZ)
{
	glm::mat4 model =
		glm::translate(positionXYZ) *
		glm::rotate(glm::radians(xRot), glm::vec3(1, 0, 0)) *
		glm::rotate(glm::radians(yRot), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::radians(zRot), glm::vec3(0, 0, 1)) *
		glm::scale(scaleXYZ);

	m_pShaderManager->setMat4Value(g_ModelName, model);
}

/***********************************************************
 *  Shader Color
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redValue,
	float greenValue,
	float blueValue,
	float alphaValue)
{
	m_pShaderManager->setVec4Value("objectColor", glm::vec4(redValue, greenValue, blueValue, alphaValue));
}

/***********************************************************
 *  Set texture
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string tag)
{
	if (tag == "")
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		return;
	}

	int slot = FindTextureSlot(tag);

	if (slot < 0)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		return;
	}

	m_pShaderManager->setIntValue(g_UseTextureName, true);
	m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
}

/***********************************************************
 *  Set material
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string tag)
{
	OBJECT_MATERIAL material;

	if (FindMaterial(tag, material))
	{
		m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
		m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
		m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
		m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
		m_pShaderManager->setFloatValue("material.shininess", material.shininess);
	}
}

/***********************************************************
 *  UV scale
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 *  Define object materials
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL wood;
	wood.ambientColor = glm::vec3(0.3f, 0.2f, 0.1f);
	wood.ambientStrength = 0.2f;
	wood.diffuseColor = glm::vec3(0.4f, 0.3f, 0.2f);
	wood.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	wood.shininess = 5.0f;
	wood.tag = "wood";
	m_objectMaterials.push_back(wood);

	OBJECT_MATERIAL marble;
	marble.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	marble.ambientStrength = 0.3f;
	marble.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	marble.specularColor = glm::vec3(1.0f, 1.0f, 1.0f);
	marble.shininess = 64.0f;
	marble.tag = "marble";
	m_objectMaterials.push_back(marble);

	OBJECT_MATERIAL floor;
	floor.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	floor.ambientStrength = 0.2f;
	floor.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	floor.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	floor.shininess = 2.0f;
	floor.tag = "floor";
	m_objectMaterials.push_back(floor);

	OBJECT_MATERIAL ceramic;
	ceramic.ambientColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramic.ambientStrength = 0.4f;
	ceramic.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramic.specularColor = glm::vec3(0.8f, 0.8f, 0.8f);
	ceramic.shininess = 32.0f;
	ceramic.tag = "ceramic";
	m_objectMaterials.push_back(ceramic);
}

/***********************************************************
 *  Setup scene lights
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/***********************************************************
	 * MAIN ROOM LIGHT
	 ***********************************************************/
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 3.0f, 2.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.55f, 0.55f, 0.58f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.85f, 0.85f, 0.90f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.45f, 0.45f, 0.50f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.4f);

	/***********************************************************
	 * DESK LAMP (warm)
	 ***********************************************************/
	m_pShaderManager->setVec3Value("lightSources[1].position", 2.00f, -0.15f, 0.38f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.24f, 0.20f, 0.16f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.48f, 0.40f, 0.30f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.30f, 0.26f, 0.20f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 12.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.3f);

	/***********************************************************
	 * SOFT FILL LIGHT (makes room visible)
	 ***********************************************************/
	m_pShaderManager->setVec3Value("lightSources[2].position", 0.0f, 1.5f, -2.0f);

	// very soft, just to lift darkness
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.32f, 0.32f, 0.35f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.45f, 0.45f, 0.50f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.10f, 0.10f, 0.12f);

	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 8.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.2f);
}

/***********************************************************
 *  Prepare Scene
 ***********************************************************/
void SceneManager::PrepareScene()
{
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();

	CreateGLTexture("textures/marble.jpg", "tableTexture");
	CreateGLTexture("textures/wood2.jpg", "floorTexture");
	CreateGLTexture("textures/wood.jpg", "legsTexture");

	BindGLTextures();

	DefineObjectMaterials();
	SetupSceneLights();
}
/***********************************************************
 *  Render Scene
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/***********************************************************
	 * FLOOR
	 ***********************************************************/
	scaleXYZ = glm::vec3(20.0f, 1.0f, 20.0f);
	positionXYZ = glm::vec3(0.0f, -4.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("floorTexture");
	SetShaderMaterial("floor");
	SetTextureUVScale(8.0f, 8.0f);
	m_basicMeshes->DrawPlaneMesh();

	/***********************************************************
	 * TABLE TOP
	 ***********************************************************/
	scaleXYZ = glm::vec3(8.0f, 0.5f, 4.0f);
	positionXYZ = glm::vec3(0.0f, -1.0f, 0.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderTexture("tableTexture");
	SetShaderMaterial("marble");
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
	 * TABLE LEGS
	 ***********************************************************/
	scaleXYZ = glm::vec3(0.3f, 3.0f, 0.3f);

	glm::vec3 legPositions[] =
	{
		glm::vec3(-3.5f, -2.5f,  1.5f),
		glm::vec3(3.5f, -2.5f,  1.5f),
		glm::vec3(-3.5f, -2.5f, -1.5f),
		glm::vec3(3.5f, -2.5f, -1.5f)
	};

	for (int i = 0; i < 4; i++)
	{
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, legPositions[i]);
		SetShaderTexture("legsTexture");
		SetShaderMaterial("wood");
		SetTextureUVScale(1.0f, 3.0f);
		m_basicMeshes->DrawBoxMesh();
	}

	/***********************************************************
	 * KEYBOARD
	 ***********************************************************/
	SetShaderTexture("");
	SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f);
	scaleXYZ = glm::vec3(2.0f, 0.12f, 0.8f);
	positionXYZ = glm::vec3(0.0f, -0.64f, 0.90f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
	 * MONITOR FRAME
	 ***********************************************************/
	SetShaderTexture("");
	SetShaderColor(0.03f, 0.03f, 0.03f, 1.0f);
	scaleXYZ = glm::vec3(2.3f, 1.3f, 0.18f);
	positionXYZ = glm::vec3(0.0f, -0.05f, -1.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
	 * MONITOR SCREEN
	 ***********************************************************/
	SetShaderTexture("");
	SetShaderColor(0.20f, 0.50f, 0.90f, 1.0f);
	scaleXYZ = glm::vec3(2.0f, 1.05f, 0.04f);
	positionXYZ = glm::vec3(0.0f, -0.05f, -0.85f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
	 * MONITOR STAND POLE
	 ***********************************************************/
	SetShaderTexture("");
	SetShaderColor(0.18f, 0.18f, 0.18f, 1.0f);
	scaleXYZ = glm::vec3(0.10f, 0.25f, 0.10f);
	positionXYZ = glm::vec3(0.0f, -0.55f, -1.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
	 * MONITOR STAND BASE
	 ***********************************************************/
	SetShaderTexture("");
	SetShaderColor(0.18f, 0.18f, 0.18f, 1.0f);
	scaleXYZ = glm::vec3(0.55f, 0.08f, 0.40f);
	positionXYZ = glm::vec3(0.0f, -0.72f, -1.0f);
	SetTransformations(scaleXYZ, 90.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
	 * COFFEE MUG BODY
	 ***********************************************************/
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderTexture("");
	SetShaderMaterial("ceramic");
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	scaleXYZ = glm::vec3(0.15f, 0.30f, 0.15f);
	positionXYZ = glm::vec3(-2.05f, -0.60f, 0.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
	 * COFFEE SURFACE
	 ***********************************************************/
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderTexture("");
	SetShaderMaterial("ceramic");
	SetShaderColor(0.30f, 0.18f, 0.10f, 1.0f);

	scaleXYZ = glm::vec3(0.12f, 0.015f, 0.12f);
	positionXYZ = glm::vec3(-2.05f, -0.46f, 0.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
	 * COFFEE MUG HANDLE
	 ***********************************************************/
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderTexture("");
	SetShaderMaterial("ceramic");
	SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f);

	scaleXYZ = glm::vec3(0.045f, 0.14f, 0.045f);
	positionXYZ = glm::vec3(-1.86f, -0.54f, 0.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
	 * LAMP BASE
	 ***********************************************************/
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderTexture("");
	SetShaderColor(0.90f, 0.82f, 0.80f, 1.0f);

	scaleXYZ = glm::vec3(0.32f, 0.12f, 0.32f);
	positionXYZ = glm::vec3(2.00f, -0.72f, 0.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawHalfSphereMesh();

	/***********************************************************
	 * LAMP POST
	 ***********************************************************/
	SetShaderColor(0.72f, 0.68f, 0.66f, 1.0f);

	scaleXYZ = glm::vec3(0.03f, 0.24f, 0.03f);
	positionXYZ = glm::vec3(2.00f, -0.48f, 0.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
	 * LAMP CONNECTOR (anchored to post top)
	 ***********************************************************/
	SetShaderColor(0.72f, 0.68f, 0.66f, 1.0f);

	scaleXYZ = glm::vec3(0.03f, 0.26f, 0.03f);
	positionXYZ = glm::vec3(2.00f, -0.36f, 0.38f);  // SAME X as post
	SetTransformations(scaleXYZ, 0.0f, 0.0f, -40.0f, positionXYZ);
	m_basicMeshes->DrawBoxMesh();


	/***********************************************************
	 * LAMP BULB 
	 ***********************************************************/
	SetShaderColor(0.98f, 0.92f, 0.84f, 1.0f);

	scaleXYZ = glm::vec3(0.11f, 0.11f, 0.11f);
	positionXYZ = glm::vec3(2.10f, -0.22f, 0.38f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	m_basicMeshes->DrawSphereMesh();
}