///////////////////////////////////////////////////////////////////////////////
// shadermanager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <vector>
#include <string>

/***********************************************************
 *  SceneManager
 ***********************************************************/
class SceneManager
{
public:
	// constructor / destructor
	SceneManager(ShaderManager* pShaderManager);
	~SceneManager();

	// texture structure
	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	// material structure
	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// core systems
	ShaderManager* m_pShaderManager;
	ShapeMeshes* m_basicMeshes;

	// textures
	int m_loadedTextures;
	TEXTURE_INFO m_textureIDs[16];

	// materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// internal helpers
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);
	int FindTextureSlot(std::string tag);

	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	void SetShaderColor(
		float redValue,
		float greenValue,
		float blueValue,
		float alphaValue);

	void SetShaderTexture(std::string textureTag);
	void SetShaderMaterial(std::string materialTag);
	void SetTextureUVScale(float u, float v);

public:
	// main scene functions
	void PrepareScene();
	void RenderScene();

	// lighting + materials
	void SetupSceneLights();
	void DefineObjectMaterials();

	// texture functions
	bool CreateGLTexture(const char* filename, std::string tag);
	void BindGLTextures();
	void DestroyGLTextures();
};